package br.senai.sc.livros.model.dao;

import br.senai.sc.livros.model.entities.*;

import javax.swing.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class LivroDAO {

    private static ArrayList<Livro> listaLivros = new ArrayList<>();

    static {
    }

    public void inserir(Livro livro) {
        if(selecionar(livro.getIsbn()) == null) {
            listaLivros.add(livro);
        } else {
            throw new RuntimeException();
        }
    }

    public void remover(Livro livro) {
        listaLivros.remove(livro);
    }

    public Livro selecionar(int isbn) {
        for(Livro livro: listaLivros) {
            if(livro.getIsbn() == isbn) {
                return livro;
            }
        }
        return null;
    }

    public void atualizar(int isbn, Livro livroAtualizado) {
        int contagem = 0;
        for(int i = 0; i < listaLivros.size(); i++) {
            if(listaLivros.get(i).getIsbn() == isbn) {
                listaLivros.set(i, livroAtualizado);
                contagem++;
            }
        }
        if(contagem == 0) {
            throw new RuntimeException();
        }
    }

    public ArrayList<Livro> selecionarTodos() {
        return listaLivros;
    }

    public ArrayList<Livro> selecionarPorAutor(Pessoa pessoa) {
        ArrayList<Livro> livrosAutor = new ArrayList<>();
        for(Livro livro: listaLivros) {
            if(livro.getAutor().equals(pessoa)) {
                livrosAutor.add(livro);
            }
        }
        return livrosAutor;
    }

    public ArrayList<Livro> selecionarPorStatus(Status status) {
        ArrayList<Livro> livrosStatus = new ArrayList<>();
        for(Livro livro: listaLivros) {
            if(livro.getStatus().equals(status)) {
                livrosStatus.add(livro);
            }
        }
        return livrosStatus;
    }

    public ArrayList<Livro> selecionarAtividadesAutor(Pessoa pessoa) {
        ArrayList<Livro> livrosAutor = new ArrayList<>();
        if(listaLivros.isEmpty()) {
            return null;
        }
        for(Livro livro: listaLivros) {
            if(livro.getAutor().equals(pessoa) && livro.getStatus().equals(Status.AGUARDANDO_EDICAO)) {
                livrosAutor.add(livro);
            }
        }
        return livrosAutor;
    }
}
